//
//  main.swift
//  AirlineReservation1
//
//  Created by MacStudent on 2018-07-26.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

var foram = Flight()
print(foram.display())
print(foram.displayData())

