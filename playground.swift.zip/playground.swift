import Foundation 

func add(n1: Int, _ n2: Int) -> Int {

    return(n1+n2)
}
var sum = add(n1: 10,40)
print("sum = \(sum)")

func subtract(x: Float, y: Float) -> Float {

    return(x-y)
}

var sub = subtract(x: 10.00, y: 5.00)
print("sub = \(sub)")

func mul(a: Int, b: Int) -> Int {

    return(a * b)
}
print("multiplication is =  \(mul(a: 10, b: 3))")

func swap(j: Int, k: Int) -> (Int,Int) {

//fn argumemnts are let constant by default
//    var temp = j
 //   j=k
 //   k=temp
    return(k,j)
}

var (p,q) = swap(j: 2, k: 4)
print("p= \(p) q= \(q)")

func swap(j: inout Int, k: inout Int){

    let temp = j
    j = k
    k = temp
}
//(a,b) swap(j: 12, k: 14)
//print("j= \(j) k: \(k)")

var n1 = 10, n2 = 20
swap(&n1, &n2)//& is used to refer variables
print("n1 = \(n1) n2= \(n2)")

func Si(amount: Double, years: Double = 3, rate: Double = 2.3) -> Double{
    return ((amount * years * rate)/100)
}

print("deposite 1: \(Si(amount: 1000.00, years: 1, rate: 5.2))")
print("deposite 2: \(Si(amount: 1000.00, years: 2))")
print("deposite 1: \(Si(amount: 5000.00))")

//variadic 
func wishes(wishList: String...){
    for eachWish in wishList{
        print("\(eachWish)")
    }
    }
    wishes(wishList: "Happy birthnday","Have a blast","party")
     wishes(wishList: "Subhakanshalu","Shubhkamnaye","janmadivas ni shubhkamnao")

func addArray(arrays: [Int]...) -> [Int] {
    var a = arrays.count
    print("a = \(a)")//stores array in a

    var array1 = arrays[0]//stores an array at index 0
    var array2 = arrays[1]
   
    var sumArray = [Int]()
     
     if array1.count == array2.count{
         for itr in 0..<array1.count{
             sumArray.append(array1[itr] + array2[itr])
         }

     }

    return sumArray

}
var arg1 = [1,2,3,4,5]
var arg2 = [6,7,8,9,10]
var result = addArray(arrays: arg1,arg2)
print("result: \(result)")

//fn as a type
var someOper : (Int,Int) -> Int = mul//need to have same prototype
 print("multiplication = \(someOper(2,5))")

 someOper = add
 print("addition = \(someOper(3,6))")

 //funtction as a parameter
func mathOper(someFunc: (Int,Int) -> Int, n1: Int, n2: Int)
{
     print("math operations : \(someFunc(n1,n2))")
 }
/// mathOper(somefunc: mul, n1: 3, n2: 3)
 // mathOper(somefunc: add, n1: 3, n2: 3)

//function as areturn  type
 func increase(_ input: Int) -> Int{

     return (input + 1)
 }

 func decrease(_ input: Int) -> Int{
     return(input - 1)
 }

 func counting(flag: Bool) -> (Int) -> Int{
//if flag{
  //  return increase
//}else{
   // return decrease
//}
 return flag ? increase : decrease
 }

 var countFunc = counting(flag: true)
 print("\(countFunc(3))")

 countFunc = counting(flag: false)
 print("\(countFunc(3))")

