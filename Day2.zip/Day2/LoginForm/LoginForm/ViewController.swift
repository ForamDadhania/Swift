//
//  ViewController.swift
//  LoginForm
//
//  Created by MacStudent on 2018-08-04.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var labelPassword: UILabel!
    @IBOutlet weak var textPassword: UITextField!
    @IBOutlet weak var labelUsername: UILabel!
    @IBOutlet weak var textUsername: UITextField!
    @IBOutlet weak var SegmentButton: UISegmentedControl!
    
    
    @IBAction func btnLoginAction(_ sender: Any) {
      
        let clickButton = sender as! UIButton
        var name = "Foram"
        var password = "Dadhania"
        
        if textUsername.text == name && textPassword.text == password {
            
            let popup = UIAlertController(title: "Login", message: "Login Suucessful", preferredStyle: UIAlertControllerStyle.alert)
            popup.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
            self.present(popup, animated: true, completion: nil)
            
        }else {
            let popup = UIAlertController(title: "Login", message: "Login Unsucessful", preferredStyle: UIAlertControllerStyle.alert)
            popup.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
            self.present(popup, animated: true, completion: nil)
        }
        
        }
    
    
    @IBAction func textLogionAction(_ sender: Any) {
        let segmentBtn = sender as! UISegmentedControl
        switch segmentBtn.selectedSegmentIndex {
        case 1:
            print("First is selected")
            
        case 2:
            print("Second is selected")
        default:
            print("")
        }
//        if segmentBtn.selectedSegmentIndex == 1 {
//
//        } else if segmentBtn.selectedSegmentIndex == 2 {
//
//        }
        
    }
    
    @IBAction func normalSegment(_ sender: Any) {
        let segment = sender as! UISegmentedControl
        print("Selected segment is : \(segment.selectedSegmentIndex)")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

