//
//  RegisterVC.swift
//  LoginForm
//
//  Created by MacStudent on 2018-08-04.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class RegisterVC: UIViewController {

    @IBOutlet weak var textFirst: UITextField!
    @IBOutlet weak var textAddress: UITextField!
   
    @IBAction func textBirthdate(_ sender: UITextField) {
        let datePickerView: UIDatePicker = UIDatePicker()
        datePickerView.datePickerMode = UIDatePickerMode.date
        sender.inputView = datePickerView
//        datePickerView.addTarget(self, action: #selector(ViewController), for: <#T##UIControlEvents#>)
    }
    @IBAction func textBirthdateEditing(_ sender: UIDatePicker) {
    }
    
    @IBAction func textGenderAction(_ sender: Any) {
    }
    
    
    @IBOutlet weak var textPhone: UITextField!
    
    @IBOutlet weak var textEmail: UITextField!
    @IBOutlet weak var textpassword: UITextField!
    
    @IBOutlet weak var textConfirmPassword: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
