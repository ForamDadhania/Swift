//
//  Register.swift
//  LoginForm
//
//  Created by MacStudent on 2018-08-04.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class Register: NSObject {

}
